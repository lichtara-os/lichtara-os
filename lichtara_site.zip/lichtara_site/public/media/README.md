Ambient audio placeholder

This folder is intended to hold the ambient MP3 used by the portal.

Filename expected by the code: `ambient.mp3` (path: `/public/media/ambient.mp3`).

Please place a royalty-free MP3 here if you want a packaged track. The script will try to load that file; if not present it falls back to a gentle WebAudio synth.

Suggested sources for royalty-free ambient tracks:
- Free Music Archive (FMA)
- https://freesound.org (check license)
- You can also create a short loop in Audacity and export as MP3.

When you add a real `ambient.mp3`, re-run the site and toggle the sound on to play it.
